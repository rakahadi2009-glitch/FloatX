# FloatX Android

FloatX is an Android Studio starter project for a Floatee-inspired floating utility app.

## Build APK
1. Install Android Studio (Hedgehog or newer) and Android SDK 35.
2. Open this folder as a project.
3. Wait for Gradle sync.
4. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Install the generated APK from `app/build/outputs/apk/debug/app-debug.apk`.

## First run
- Open FloatX.
- Tap **Aktifkan floating bubble**.
- Allow **Display over other apps** in Android settings.
- Return to FloatX. Tap the floating bubble to open its quick panel.

## Current implementation
- Dark dashboard and tool cards.
- Android overlay permission flow.
- Draggable floating bubble and quick panel.
- Notes and text input UI.
- Browser handoff to the installed browser.

## Important limitations
This is a functional starter project, not a finished clone of Floatee. AI responses and automatic translation need a secure backend/API integration. Notes are currently in-memory (not persistent). Mini Browser currently opens the external browser. Android does not allow unrestricted access to other apps' screen content; screen translation/OCR needs explicit capture permission and careful privacy handling. The quick panel is a starter launcher, not a full floating-window system for every tool.

Do not put private API keys directly in the Android app. Use a backend for AI/translation services.
