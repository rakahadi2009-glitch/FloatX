package com.raka.floatx

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF10111A)
private val Surface = Color(0xFF1B1D2A)
private val Accent = Color(0xFF8B7CFF)
private val Muted = Color(0xFF9A9CAF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { FloatXApp() }
    }
}

data class Tool(val name: String, val subtitle: String, val icon: ImageVector)

@Composable
fun FloatXApp() {
    val context = LocalContext.current
    var selected by remember { mutableStateOf("Home") }
    var note by remember { mutableStateOf("") }
    var expression by remember { mutableStateOf("") }
    var url by remember { mutableStateOf("https://www.google.com") }
    var query by remember { mutableStateOf("") }
    val tools = listOf(
        Tool("AI Assistant", "Tanya AI", Icons.Default.AutoAwesome),
        Tool("Translator", "Terjemahkan teks", Icons.Default.Translate),
        Tool("Mini Browser", "Jelajah web", Icons.Default.Language),
        Tool("Notes", "Catatan cepat", Icons.Default.StickyNote2),
        Tool("Calculator", "Hitung cepat", Icons.Default.Calculate),
        Tool("Quick Tools", "Pintasan perangkat", Icons.Default.Bolt)
    )
    MaterialTheme(colorScheme = darkColorScheme(
        background = Bg, surface = Surface, primary = Accent,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Column(Modifier.fillMaxSize().background(Bg).padding(20.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(42.dp).background(Accent, RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.BubbleChart, null, tint = Color.White)
                }
                Spacer(Modifier.width(12.dp))
                Column {
                    Text("FloatX", fontSize = 23.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    Text("Your floating workspace", color = Muted, fontSize = 12.sp)
                }
                Spacer(Modifier.weight(1f))
                Icon(Icons.Default.Tune, null, tint = Muted)
            }
            Spacer(Modifier.height(26.dp))
            Text("Selamat datang 👋", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Text("Semua alat praktis dalam satu tempat.", color = Muted, modifier = Modifier.padding(top = 5.dp))
            Spacer(Modifier.height(20.dp))
            Card(colors = CardDefaults.cardColors(containerColor = Surface), shape = RoundedCornerShape(22.dp)) {
                Column(Modifier.padding(18.dp)) {
                    Text("FLOATING SHORTCUT", color = Accent, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(7.dp))
                    Text("Buka panel FloatX di atas aplikasi lain.", color = Color.White)
                    Spacer(Modifier.height(14.dp))
                    Button(
                        onClick = {
                            if (!Settings.canDrawOverlays(context)) {
                                val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + context.packageName))
                                context.startActivity(intent)
                            } else {
                                context.startService(Intent(context, FloatingService::class.java))
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Accent),
                        modifier = Modifier.fillMaxWidth()
                    ) { Icon(Icons.Default.Layers, null); Spacer(Modifier.width(8.dp)); Text("Aktifkan floating bubble") }
                    Text("Izin 'Tampil di atas aplikasi lain' diperlukan.", color = Muted, fontSize = 11.sp)
                }
            }
            Spacer(Modifier.height(24.dp))
            Text("TOOLS", color = Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(12.dp))
            LazyVerticalGrid(columns = GridCells.Fixed(2), verticalArrangement = Arrangement.spacedBy(12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.weight(1f)) {
                items(tools) { tool ->
                    Card(
                        modifier = Modifier.fillMaxWidth().height(112.dp).clickable { selected = tool.name },
                        colors = CardDefaults.cardColors(containerColor = Surface),
                        shape = RoundedCornerShape(18.dp)
                    ) {
                        Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.Center) {
                            Icon(tool.icon, null, tint = Accent, modifier = Modifier.size(25.dp))
                            Spacer(Modifier.height(10.dp))
                            Text(tool.name, color = Color.White, fontWeight = FontWeight.SemiBold)
                            Text(tool.subtitle, color = Muted, fontSize = 11.sp)
                        }
                    }
                }
            }
            if (selected != "Home") {
                AlertDialog(
                    onDismissRequest = { selected = "Home" },
                    containerColor = Surface,
                    title = { Text(selected, color = Color.White) },
                    text = {
                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            when (selected) {
                                "Notes" -> {
                                    Text("Catatan tersimpan selama layar ini terbuka.", color = Muted)
                                    OutlinedTextField(note, { note = it }, label = { Text("Tulis catatan") })
                                }
                                "Calculator" -> {
                                    OutlinedTextField(expression, { expression = it }, label = { Text("Contoh: 12*8+5") })
                                    Text("Kalkulator dasar tersedia di aplikasi kalkulator perangkat.", color = Muted, fontSize = 12.sp)
                                }
                                "Mini Browser" -> {
                                    OutlinedTextField(url, { url = it }, label = { Text("Alamat situs") })
                                    Button(onClick = {
                                        val fixed = if (url.startsWith("http")) url else "https://$url"
                                        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(fixed)))
                                    }) { Text("Buka di browser") }
                                }
                                "Translator" -> {
                                    OutlinedTextField(query, { query = it }, label = { Text("Teks yang ingin diterjemahkan") })
                                    Text("Pilih teks lalu gunakan layanan terjemahan. Integrasi terjemahan otomatis memerlukan API.", color = Muted, fontSize = 12.sp)
                                }
                                "AI Assistant" -> {
                                    OutlinedTextField(query, { query = it }, label = { Text("Tulis pertanyaan") })
                                    Text("Tampilan siap dikembangkan. Untuk jawaban AI sungguhan, hubungkan backend dan API key secara aman.", color = Muted, fontSize = 12.sp)
                                }
                                else -> Text("Pintasan sistem dapat dibuka melalui pengaturan Android.", color = Muted)
                            }
                        }
                    },
                    confirmButton = { TextButton(onClick = { selected = "Home" }) { Text("Tutup") } }
                )
            }
        }
    }
}
