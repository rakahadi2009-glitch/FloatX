package com.raka.floatx

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.Color
import android.graphics.Typeface
import android.view.MotionEvent
import android.view.View

class FloatingService : Service() {
    private lateinit var wm: WindowManager
    private var bubble: View? = null
    private var panel: View? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        showBubble()
    }

    private fun params(width: Int, height: Int) = WindowManager.LayoutParams(
        width, height,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
        PixelFormat.TRANSLUCENT
    ).apply { gravity = Gravity.TOP or Gravity.END; x = 24; y = 220 }

    private fun showBubble() {
        val b = TextView(this).apply {
            text = "F"
            textSize = 21f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setBackgroundColor(Color.rgb(139, 124, 255))
            setOnClickListener { showPanel() }
            setOnTouchListener(object : View.OnTouchListener {
                var downX = 0f; var downY = 0f; var startX = 0; var startY = 0
                override fun onTouch(v: View, e: MotionEvent): Boolean {
                    val p = bubble?.layoutParams as? WindowManager.LayoutParams ?: return false
                    when (e.action) {
                        MotionEvent.ACTION_DOWN -> { downX=e.rawX; downY=e.rawY; startX=p.x; startY=p.y; return true }
                        MotionEvent.ACTION_MOVE -> { p.x = startX + (downX-e.rawX).toInt(); p.y = startY + (e.rawY-downY).toInt(); wm.updateViewLayout(v,p); return true }
                        MotionEvent.ACTION_UP -> { if (kotlin.math.abs(e.rawX-downX)<8 && kotlin.math.abs(e.rawY-downY)<8) showPanel(); return true }
                    }
                    return false
                }
            })
        }
        bubble = b
        wm.addView(b, params(58, 58).apply { flags = flags or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL })
    }

    private fun showPanel() {
        if (panel != null) { wm.removeView(panel); panel = null; return }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 24, 28, 24)
            setBackgroundColor(Color.rgb(27, 29, 42))
        }
        val title = TextView(this).apply { text = "FloatX  •  Quick panel"; textSize = 18f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD }
        box.addView(title)
        listOf("AI Assistant", "Translator", "Notes", "Calculator", "Mini Browser").forEach { name ->
            val btn = Button(this).apply {
                text = name
                setOnClickListener {
                    val launch = packageManager.getLaunchIntentForPackage(packageName)
                    launch?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    startActivity(launch)
                }
            }
            box.addView(btn)
        }
        val close = Button(this).apply { text = "Tutup panel"; setOnClickListener { panel?.let { wm.removeView(it) }; panel = null } }
        box.addView(close)
        panel = box
        wm.addView(box, params(290, WindowManager.LayoutParams.WRAP_CONTENT).apply {
            gravity = Gravity.CENTER
            flags = WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
        })
    }

    override fun onDestroy() {
        bubble?.let { wm.removeView(it) }; panel?.let { wm.removeView(it) }
        bubble = null; panel = null
        super.onDestroy()
    }
}
