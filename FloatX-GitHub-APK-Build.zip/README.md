# FloatX Android

FloatX is an Android Studio starter project for a Floatee-inspired floating utility app.

## Build APK
1. Install Android Studio (Hedgehog or newer) and Android SDK 35.
2. Open this folder as a project.
3. Wait for Gradle sync.
4. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Install the generated APK from `app/build/outputs/apk/debug/app-debug.apk`.

## First run
- Open FloatX.
- Tap **Aktifkan floating bubble**.
- Allow **Display over other apps** in Android settings.
- Return to FloatX. Tap the floating bubble to open its quick panel.

## Current implementation
- Dark dashboard and tool cards.
- Android overlay permission flow.
- Draggable floating bubble and quick panel.
- Notes and text input UI.
- Browser handoff to the installed browser.

## Important limitations
This is a functional starter project, not a finished clone of Floatee. AI responses and automatic translation need a secure backend/API integration. Notes are currently in-memory (not persistent). Mini Browser currently opens the external browser. Android does not allow unrestricted access to other apps' screen content; screen translation/OCR needs explicit capture permission and careful privacy handling. The quick panel is a starter launcher, not a full floating-window system for every tool.

Do not put private API keys directly in the Android app. Use a backend for AI/translation services.


## Build APK using GitHub (no laptop required after upload)
1. Sign in to GitHub in your phone browser and create a new empty repository named `FloatX`.
2. Upload the contents of this ZIP into the repository (keep the `.github/workflows/android.yml` file and its folders).
3. Open the repository's **Actions** tab. The workflow named **Build FloatX APK** will run after the upload/push.
4. Open the completed workflow run, scroll to **Artifacts**, and download `FloatX-debug-APK`.
5. Extract the downloaded artifact ZIP; install `app-debug.apk` on Android. If Android asks, allow installation from that browser/file manager.

This workflow builds a debug APK. The first GitHub build may take several minutes. The workflow has not been run from this environment, so the generated APK still needs to be produced by GitHub Actions.
